## Excersices for Publishing Packages

This is a repository to experiment publishing packages